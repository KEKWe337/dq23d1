#include <iostream>
#include "Goods.h"
using namespace std;
int main() {
	int num, n;
	Goods a, b, c, d, e, f;
	a = a.Init("Apples", "07.10.2024", 10, 5, 10235456);
	a.Display();
	cout << "Enter change price ";
	cin >> num;
	b = a.ChangePrice(num);
	b.ToString();

	c.Read();
	c.Display();
	cout << "Enter change amount ";
	cin >> n;
	d = c.ChangeAmountUp(n);
	d.ToString();

	e = e.Init("Oranges", "06.10.2024", 15, 10, 10235756);
	e.Display();
	cout << "Enter change amount ";
	cin >> n;
	f = e.ChangeAmountDown(n);
	f.ToString();
	return 0;
}