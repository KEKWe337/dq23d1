#pragma once
#include <string>
using namespace std;
class Goods
{
	string name;
	string date;
	int price;
	int amount;
	int note;
public:
	Goods ChangePrice(int num);
	Goods ChangeAmountUp(int n);
	Goods ChangeAmountDown(int n);
	void ToString();
	void Read();
	void Display();
	Goods Init(string na, string d, int p, int a, int n);
	Goods();
	Goods(string n);
	Goods(string n, string d);
};
