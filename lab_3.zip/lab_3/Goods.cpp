#include <iostream>
#include <string>
#include "Goods.h"
using namespace std;

Goods Goods::ChangePrice(int num)
{
	Goods temp;
	temp.name = name;
	temp.date = date;
	temp.price = num;
	temp.amount = amount;
	temp.note = note;
	return temp;
}

Goods Goods::ChangeAmountUp(int n)
{
	Goods temp;
	temp.name = name;
	temp.date = date;
	temp.price = price;
	temp.amount = amount + n;
	temp.note = note;
	return temp;
}

Goods Goods::ChangeAmountDown(int n)
{
	Goods temp;
	temp.name = name;
	temp.date = date;
	temp.price = price;
	temp.amount = amount - n;
	temp.note = note;
	return temp;
}

void Goods::ToString()
{
	cout << "Price for 1 " << name << " is " << price << ", price for " << amount << " " << name << " is " << price * amount << endl;
	cout << endl;
}

void Goods::Read()
{
	cout << "Enter goods name ";
	cin >> name;
	cout << "Enter goods date ";
	cin >> date;
	cout << "Enter goods price ";
	cin >> price;
	cout << "Enter goods amount ";
	cin >> amount;
	cout << "Enter goods note ";
	cin >> note;
}

void Goods::Display()
{
	cout << "Name = " << name << ", date = " << date << ", price = " << price << ", amount = " << amount << ", note = " << note << endl;
	cout << endl;
}

Goods Goods::Init(string na, string d, int p, int a, int n)
{
	Goods temp;
	temp.name = na;
	temp.date = d;
	temp.price = p;
	temp.amount = a;
	temp.note = n;
	return temp;
}

Goods::Goods()
{
	name = "Apples";
	date = "05.10.2024";
	price = 15;
	amount = 10;
	note = 134562578;
}

Goods::Goods(string n)
{
	name = n;
	date = "11.10.2024";
	price = 10;
	amount = 5;
	note = 14368974;
}

Goods::Goods(string n, string d)
{
	name = n;
	date = d;
	price = 12;
	amount = 6;
	note = 112478965;
}