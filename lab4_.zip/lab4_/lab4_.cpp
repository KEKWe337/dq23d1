#include <iostream>
#include "Goods.h"
using namespace std;
int main() {
	Goods A, B("Pineapple"), C("Strawberry", "29.09.2024"), D, E, F;
	int num1, n1, n2;
	A.Display();
	cout << "Enter change price ";
	cin >> num1;
	D = A * num1;
	D.ToString();
	B.Display();
	cout << "Enter change amount ";
	cin >> n2;
	E = B+n2;
	E.ToString();
	C.Display();
	cout << "Enter change amount ";
	cin >> n2;
	F = C-n2;
	F.ToString();
	int num, n;
	Goods a, b, c, d, e, f;
	a = a.Init("Apples", "07.10.2024", 10, 5, 10235456);
	a.Display();
	cout << "Enter change price ";
	cin >> num;
	b = a*num;
	b.ToString();

	c.Read();
	c.Display();
	cout << "Enter change amount ";
	cin >> n;
	d = c+n;
	d.ToString();

	e = e.Init("Oranges", "06.10.2024", 15, 10, 10235756);
	e.Display();
	cout << "Enter change amount ";
	cin >> n;
	f = e-n;
	f.ToString();
	return 0;
}
