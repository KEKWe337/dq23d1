#pragma once
#include <string>
using namespace std;
class Goods
{
	string name;
	string date;
	int price;
	int amount;
	int note;
public:
	Goods operator *(int num);
	Goods operator +(int n);
	Goods operator -(int n);
	void ToString();
	void Read();
	void Display();
	Goods Init(string na, string d, int p, int a, int n);
	Goods();
	Goods(string n);
	Goods(string n, string d);
};
