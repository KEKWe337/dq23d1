#include "DoubleNum.h"
#include <iostream>
using namespace std;

DoubleNum DoubleNum::multiply(double num)
{
	DoubleNum temp;
	temp.first = first * num;
	temp.second = second * num;
	return temp;
}

void DoubleNum::Read()
{
	cout << "Enter int part of number " << endl;
	cin >> first;
	cout << "Enter double part of number " << endl;
	cin >> second;
}

void DoubleNum::Display()
{
	cout << "Number = " << first + second << endl;
	cout << endl;
}

DoubleNum DoubleNum::Init(double f, double s)
{
	DoubleNum temp;
	temp.first = f;
	temp.second = s;
	return temp;
}
