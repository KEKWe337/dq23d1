#include <iostream>
#include "DoubleNum.h"
using namespace std;
int main() {
	double num;
	DoubleNum a, b, c, d;
	a = a.Init(7, 0.5389);
	a.Display();
	cout << "Enter numer for multiply ";
	cin >> num;
	b = a.multiply(num);
	b.Display();
	c.Read();
	c.Display();
	cout << "Enter numer for multiply ";
	cin >> num;
	d = c.multiply(num);
	d.Display();
}