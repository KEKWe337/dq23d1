#pragma once
struct DoubleNum {
	double first;
	double second;
	DoubleNum multiply(double num);
	void Read();
	void Display();
	DoubleNum Init(double f, double s);
};